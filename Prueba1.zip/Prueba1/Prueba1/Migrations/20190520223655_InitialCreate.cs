﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Prueba1.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Proyect",
                columns: table => new
                {
                    ProyectName = table.Column<string>(nullable: false),
                    ProyectDescription = table.Column<string>(nullable: true),
                    HourLoad = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Proyect", x => x.ProyectName);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Proyect");
        }
    }
}
