using Microsoft.EntityFrameworkCore;

namespace Prueba1.Models
{

    public class Prueba1Context : DbContext
    {
        public Prueba1Context (DbContextOptions<Prueba1Context> options)
            : base(options)
        {
        }

        public DbSet<Prueba1.Models.Proyect> Proyect { get; set; }
    }
}