using System;
using System.ComponentModel.DataAnnotations;


namespace Prueba1.Models

{
    public class Proyect
   
    {
        [Key]
        public string ProyectName{get;set;}
        public string ProyectDescription{get;set;}
        public string NivelTechnician{get;set;}
        public string RolesRequired{get;set;}

        [DataType(DataType.Date)]
        public DateTime DateProyect{get;set;}
        public int HourLoad{get;set;}



    }
}