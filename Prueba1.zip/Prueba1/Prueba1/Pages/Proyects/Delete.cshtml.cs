using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Prueba1.Models;

namespace Prueba1.Pages.Proyects
{
    public class DeleteModel : PageModel
    {
        private readonly Prueba1.Models.Prueba1Context _context;

        public DeleteModel(Prueba1.Models.Prueba1Context context)
        {
            _context = context;
        }

        [BindProperty]
        public Proyect Proyect { get; set; }

        public async Task<IActionResult> OnGetAsync(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Proyect = await _context.Proyect.FirstOrDefaultAsync(m => m.ProyectName == id);

            if (Proyect == null)
            {
                return NotFound();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Proyect = await _context.Proyect.FindAsync(id);

            if (Proyect != null)
            {
                _context.Proyect.Remove(Proyect);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
