using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Prueba1.Models;

namespace Prueba1.Pages.Proyects
{
    public class IndexModel : PageModel
    {
        private readonly Prueba1.Models.Prueba1Context _context;

        public IndexModel(Prueba1.Models.Prueba1Context context)
        {
            _context = context;
        }

        public IList<Proyect> Proyect { get;set; }

        public async Task OnGetAsync()
        {
            Proyect = await _context.Proyect.ToListAsync();
        }
    }
}
